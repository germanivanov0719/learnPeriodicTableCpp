//
//  settings.hpp
//  learnPeriodicTable
//
//  Created by German Ivanov on 12/25/21.
//

#ifndef settings_hpp
#define settings_hpp

#include <string>

void initializeSettings();
std::string loadSettings();

#endif /* settings_hpp */
